const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000; // You can choose any port you prefer

// Enable CORS
app.use(cors());

// Define a route
app.get('/', (req, res) => {
    res.json({ message: 'Welcome to DressStore application.' });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
